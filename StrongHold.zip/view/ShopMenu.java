package view;

import controler.ShopControl;

public class ShopMenu {
    public void run(){}
    public void showPrices(){ShopControl shopControl = new ShopControl();}
    public void buy(){ShopControl shopControl = new ShopControl();}
    public void sell(){
        ShopControl shopControl = new ShopControl();
    }
}
