package view;

import controler.TradeControl;

public class TradeMenu {
    public void run(){}
    public void showTradeList(){
        TradeControl tradeControl = new TradeControl();
    }
    public void tradeRequest(){
        TradeControl tradeControl = new TradeControl();
    }
    public void acceptTrade(){
        TradeControl tradeControl = new TradeControl();
    }
    public void tradeHistory(){
        TradeControl tradeControl = new TradeControl();
    }
}
