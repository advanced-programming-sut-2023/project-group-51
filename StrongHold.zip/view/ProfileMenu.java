package view;

public class ProfileMenu {
    public void changeUserName(){
    }
    public void changeNickname(){

    }
    public void changePassword(){

    }
    public void changeEmail(){

    }
    public void changeSlogan(){}
    public void displayHighScore(){}
    public void displayRank(){}
    public void displaySlogan(){}
    public void displayProfile(){}
}
