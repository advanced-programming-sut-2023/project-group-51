import view.LoginMenu;

public class Main {
    public static void main(String[] args){
        LoginMenu loginMenu = new LoginMenu();
        loginMenu.run();
    }
}
