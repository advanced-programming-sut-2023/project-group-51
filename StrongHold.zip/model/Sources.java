package model;

public enum Sources {
    OIL,
    STONE,
    WOOD,
    IRON,
    METAL_ARMOUR,
    LEATHER_ARMOUR,
    SPEAR,
    PIKE,
    BOW,
    CROSSBOW,
    SWORD,
    LAVA,
    FLOUR,
    APPLE,
    BARLEY,
    MEAT,
    WHEAT,
    BREAD,
    WINE,
    CHEESE,
    HORSE;
}
