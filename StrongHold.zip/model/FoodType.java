package model;

public enum FoodType {
    APPLE,
    BREAD,
    CHEESE,
    MEAT;
}
