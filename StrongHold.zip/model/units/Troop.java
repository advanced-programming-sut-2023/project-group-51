package model.units;

public class Troop extends Unit{
    protected int defenseStrength;
    protected int attackStrength;
}
