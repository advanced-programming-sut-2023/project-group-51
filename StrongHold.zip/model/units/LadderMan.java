package model.units;

public class LadderMan extends Troop{
}
