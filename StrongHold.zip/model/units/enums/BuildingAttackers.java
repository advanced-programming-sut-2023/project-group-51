package model.units.enums;

public enum BuildingAttackers {
    TUNNELER, SLAVES;
}
