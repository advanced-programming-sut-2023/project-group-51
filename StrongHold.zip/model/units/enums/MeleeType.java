package model.units.enums;

public enum MeleeType {
    SPEARMAN,
    MACEMAN,
    SWORDMAN,
    PIKEMAN,
    BLACKMONK,
    ARABIAN_SWORDMAN;
}
