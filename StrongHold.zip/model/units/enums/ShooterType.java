package model.units.enums;

public enum ShooterType {
    CATAPULT,
    TREBUCHET,
    FIRE_BALLISTA,
    CATAPULT_ON_TOWER,
    FIRE_BALLISTA_ON_TOWER;
}
