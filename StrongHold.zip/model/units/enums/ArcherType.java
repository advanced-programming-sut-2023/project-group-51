package model.units.enums;

public enum ArcherType {
    ARCHER,
    SLINGER,
    HORSE_ARCHER,
    ARCHER_BOW,
    CROSSBOW_MEN;
}
