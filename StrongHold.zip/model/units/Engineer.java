package model.units;

public class Engineer extends Troop{
}
