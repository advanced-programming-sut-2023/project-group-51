package model.units;

public class Shooter extends WarTool{
}
