package model.units;

public class WarTool extends Unit{

}
