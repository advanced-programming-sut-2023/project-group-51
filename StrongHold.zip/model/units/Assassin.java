package model.units;

public class Assassin extends Troop{
}
