package model.units;

public class SiegeTower extends WarTool{
}
