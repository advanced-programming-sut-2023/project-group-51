package model.units;

public class BattleRam extends WarTool{
}
