package model.units;

public class PortableShield extends WarTool{
}
