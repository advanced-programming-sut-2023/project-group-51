package model.units;

public class Knight extends Troop{
}
