package model.units;

public class Archer extends Troop{
}
