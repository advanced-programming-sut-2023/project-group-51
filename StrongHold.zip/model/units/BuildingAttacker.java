package model.units;

public class BuildingAttacker extends Troop{
}
