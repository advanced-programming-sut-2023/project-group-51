package model.buildings;

public class Hovel extends Building{
    private int peopleIncrease;
}
