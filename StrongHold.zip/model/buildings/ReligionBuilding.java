package model.buildings;

public class ReligionBuilding extends Building{
    private int popularity;
}
