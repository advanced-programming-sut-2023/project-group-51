package model.buildings;

public class Industry extends Building{
    private int rate;
}
