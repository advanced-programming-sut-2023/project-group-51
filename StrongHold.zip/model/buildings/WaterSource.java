package model.buildings;

public class WaterSource extends Building{
}
