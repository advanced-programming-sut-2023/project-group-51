package model.buildings;

public class FoodProcessingBuildings extends Building{
    private int rate;
    private int popularity;
    private int goodsUsage;
}
