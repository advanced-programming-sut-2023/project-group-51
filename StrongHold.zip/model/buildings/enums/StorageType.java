package model.buildings.enums;

public enum StorageType {
    ARMOURY,
    STOCKPILE,
    FOOD_STORAGE;
}
