package model.buildings.enums;

public enum IndustryType {
    STABLE,
    OIL_SMELTER,
    WOOD_CUTTER,
    QUARRY,
    PITCH_RIG,
    OX_TETHER,
    IRON_MINE;
}
