package model.buildings.enums;

public enum GateType {
    DRAW_BRIDGE,
    SMALL_STONE_GATE_HOUSE,
    BIG_STONE_GATE_HOUSE;
}
