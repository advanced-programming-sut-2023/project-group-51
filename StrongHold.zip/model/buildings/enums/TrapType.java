package model.buildings.enums;

public enum TrapType {
    PITCH_DITCH,
    CAGED_WAR_DOGS;
}
