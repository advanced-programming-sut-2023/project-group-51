package model.buildings.enums;

public enum WeaponBuildingType {
    ARMOURER,
    TANNER,
    BLACKSMITH,
    FLETCHER,
    POLE_TURNER;
}
