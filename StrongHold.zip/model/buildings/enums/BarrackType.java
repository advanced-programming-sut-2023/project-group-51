package model.buildings.enums;

public enum BarrackType {
    BARRACK,
    MERCENARY_POST,
    ENGINEER_GUILD,
    SIEGE_TENT;
}
