package model.buildings.enums;

public enum TowerType {
    TURRET,
    LOOKOUT_TOWER,
    ROUND_TOWER,
    SQUARE_TOWER,
    PERIMETER_TOWER;
}
