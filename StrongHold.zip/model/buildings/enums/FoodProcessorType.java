package model.buildings.enums;

public enum FoodProcessorType {
    BAKERY,
    BREWERY,
    HUNTERS_HUT,
    MILL,
    INN;
}
