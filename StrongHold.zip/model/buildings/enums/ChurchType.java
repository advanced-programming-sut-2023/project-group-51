package model.buildings.enums;

public enum ChurchType {
    CHURCH,
    CATHEDRAL;
}
