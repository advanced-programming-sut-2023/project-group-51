package model.buildings.enums;

public enum FarmType {
    WHEAT_FARM,
    BARLEY_FARM,
    DAIRY_FARM,
    ORCHARD;
}
