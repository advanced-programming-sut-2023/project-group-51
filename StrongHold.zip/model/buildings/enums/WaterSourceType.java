package model.buildings.enums;

public enum WaterSourceType {
    WELL,
    WATER_POT;
}
