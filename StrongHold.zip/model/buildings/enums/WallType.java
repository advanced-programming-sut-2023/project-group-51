package model.buildings.enums;

public enum WallType {
    TALL,
    SHORT;
}
