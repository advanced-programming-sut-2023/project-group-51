package model.buildings.castleBuildings;

import model.buildings.Building;

public class CastleBuilding extends Building {
}
