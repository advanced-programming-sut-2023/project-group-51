package model.buildings.castleBuildings;

public class Gate extends CastleBuilding{
}
