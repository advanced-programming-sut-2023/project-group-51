package model.buildings.castleBuildings;

public class Tower extends CastleBuilding{
    private int fireRange;
    private int defendRange;
}
