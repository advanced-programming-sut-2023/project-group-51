package model.buildings.castleBuildings;

public class Trap extends CastleBuilding{
    private int damage;
}
