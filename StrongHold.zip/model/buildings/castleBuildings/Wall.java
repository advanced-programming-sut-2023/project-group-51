package model.buildings.castleBuildings;

public class Wall extends CastleBuilding{
}
