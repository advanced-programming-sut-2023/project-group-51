package model.buildings;

public class FarmBuildings extends Building{
    private int rate;

}
