package model.buildings;

public class WeaponBuildings extends Building{
    private int rate;
    private int goodsUsage;
}
