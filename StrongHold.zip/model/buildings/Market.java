package model.buildings;

public class Market extends Building{
}
