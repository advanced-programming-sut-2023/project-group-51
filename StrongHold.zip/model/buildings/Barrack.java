package model.buildings;

public class Barrack extends Building{
}
