package model.worldMap;

import java.util.ArrayList;
import java.util.List;

public class Map {
    public static Tile[][] coordinates;
    List<Tile> tiles = new ArrayList<>();
    public void setTileType(int x, int y){}
    public void makeDefaultMap(int length, int width){
    }
}
