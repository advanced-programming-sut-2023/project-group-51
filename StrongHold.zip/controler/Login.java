package controler;

import java.util.regex.Matcher;

public class Login {
    public Login (Matcher matcher){}
    public boolean checkUsername(){return true;}
    public boolean checkPassword(){
        return true;
    }
}
