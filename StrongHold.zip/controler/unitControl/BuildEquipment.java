package controler.unitControl;

import model.units.Unit;

public class BuildEquipment {
    String name;

    public BuildEquipment(String name) {
        this.name = name;
    }
    public void build(){
        Unit unit = new Unit();
    }
}
