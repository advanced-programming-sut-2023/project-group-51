package controler;

import model.Governance;
import model.User;
import model.buildings.Storage;

public class ShopControl {
    public void sell(){
        Storage storage = new Storage();
        Governance governance = new Governance();
    }
    public void buy(){}
}
