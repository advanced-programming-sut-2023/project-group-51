package controler;

import model.buildings.Building;

public class SelectBuilding {
    int x, y;

    public SelectBuilding(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public void select(){
        Building building = new Building();
    }
}
